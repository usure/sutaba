sutaba
======

A lightweight, standalone imageboard software written in PHP. The purpose of this project was to create a "single file" imageboard, where you would only need to upload one PHP file (sutaba.php) and import the MySQL database.
